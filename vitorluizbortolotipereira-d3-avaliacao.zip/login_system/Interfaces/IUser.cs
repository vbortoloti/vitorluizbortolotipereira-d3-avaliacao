﻿using login_system.Models;

namespace login_system.Interfaces
{
    public interface IUser
    {
        //Create Read Update Delete - CRUD
        void RegisterAccess(User user);

        User GetUser(string email, string password);

    }
}
